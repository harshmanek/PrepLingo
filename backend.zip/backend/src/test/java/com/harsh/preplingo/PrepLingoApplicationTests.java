package com.harsh.preplingo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrepLingoApplicationTests {

    @Test
    void contextLoads() {
    }

}
