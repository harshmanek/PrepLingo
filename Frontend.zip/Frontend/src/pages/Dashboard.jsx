"use client"

import { useContext, useState, useEffect } from "react"
import { useNavigate } from "react-router-dom"
import { AuthContext } from "../contexts/AuthContext"
import { ProgressContext } from "../contexts/ProgressContext"
import Navbar from "../components/Navbar"
import LoadingSpinner from "../components/LoadingSpinner"
import { quizService } from "../services/api"
import "./Dashboard.css"
import logo from "../pages/logo.png";

const Dashboard = () => {
  const { currentUser, streakInfo, fetchStreakInfo } = useContext(AuthContext)
  const { userProgress, loading: progressLoading, fetchQuizStats } = useContext(ProgressContext)
  const [topics, setTopics] = useState([])
  const [quizHistory, setQuizHistory] = useState([])
  const [loading, setLoading] = useState(true)
  const navigate = useNavigate()

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Refresh streak info
        await fetchStreakInfo()

        // Refresh quiz stats
        await fetchQuizStats()

        // Fetch quiz history
        const history = await quizService.getQuizHistory()
        setQuizHistory(history)

        // In a real app, fetch topics from the backend
        // For now, we'll use mock data
        const mockTopics = [
          {
            id: "java-basics",
            title: "Java Basics",
            description: "Learn the fundamentals of Java programming",
            icon: "☕",
            level: 1,
            lessons: 5,
            completed: userProgress.completedLessons.includes("java-basics"),
          },
          {
            id: "java-oop",
            title: "Object-Oriented Programming",
            description: "Master classes, objects, inheritance, and polymorphism",
            icon: "🧩",
            level: 2,
            lessons: 4,
            completed: userProgress.completedLessons.includes("java-oop"),
          },
          {
            id: "java-collections",
            title: "Java Collections",
            description: "Learn about Lists, Sets, Maps, and more",
            icon: "📚",
            level: 3,
            lessons: 6,
            completed: false,
          },
          {
            id: "java-exceptions",
            title: "Exception Handling",
            description: "Master try-catch blocks and custom exceptions",
            icon: "⚠️",
            level: 3,
            lessons: 3,
            completed: false,
          },
          {
            id: "java-concurrency",
            title: "Concurrency",
            description: "Learn about threads, synchronization, and parallel processing",
            icon: "⚡",
            level: 4,
            lessons: 5,
            completed: false,
          },
          {
            id: "java-streams",
            title: "Streams API",
            description: "Master functional programming with Java Streams",
            icon: "🌊",
            level: 4,
            lessons: 4,
            completed: false,
          },
        ]

        setTopics(mockTopics)
      } catch (error) {
        console.error("Error fetching data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [fetchStreakInfo, fetchQuizStats])

  const handleTopicClick = (topicId) => {
    navigate(`/lesson/${topicId}`)
  }

  const handleCreateQuiz = () => {
    navigate("/dashboard/quiz/create")
  }

  const handleGenerateQuestions = () => {
    navigate("/dashboard/generate")
  }

  if (loading || progressLoading) {
    return <LoadingSpinner />
  }

  return (
    <div className="dashboard-container">
      <Navbar />

      <div className="dashboard-content">
        <div className="dashboard-header">
          <h1>Welcome back, {currentUser.username}!</h1>
          <div className="user-level">
            <div className="level-badge">Level {userProgress.level}</div>
            <div className="xp-progress">
              <div className="xp-bar" style={{ width: `${userProgress.xp % 100}%` }}></div>
              <span>{userProgress.xp % 100}/100 XP to next level</span>
            </div>
          </div>
        </div>

        <div className="streak-card">
          <div className="streak-icon">🔥</div>
          <div className="streak-info">
            <h3>{streakInfo?.streakCount || userProgress.streak} day streak!</h3>
            <p>
              {streakInfo?.maintainedToday
                ? "You've maintained your streak today!"
                : "Complete a quiz today to maintain your streak"}
            </p>
          </div>
          <button className="daily-goal-button" onClick={handleCreateQuiz}>
            Complete Daily Goal
          </button>
        </div>

        <div className="topics-container">
          <h2>Learning Paths</h2>
          <div className="topics-grid">
            {topics.map((topic) => (
              <div
                key={topic.id}
                className={`topic-card ${topic.completed ? "completed" : ""}`}
                onClick={() => handleTopicClick(topic.id)}
              >
                <div className="topic-icon">{topic.icon}</div>
                <div className="topic-info">
                  <h3>{topic.title}</h3>
                  <p>{topic.description}</p>
                  <div className="topic-meta">
                    <span className="topic-level">Level {topic.level}</span>
                    <span className="topic-lessons">{topic.lessons} lessons</span>
                  </div>
                </div>
                <div className="topic-status">
                  {topic.completed ? (
                    <div className="completed-badge">✓</div>
                  ) : (
                    <div className="start-button">Start</div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="recent-activity">
          <h2>Recent Activity</h2>
          {quizHistory.length > 0 ? (
            <div className="activity-list">
              {quizHistory.slice(0, 3).map((quiz) => (
                <div key={quiz.id} className="activity-item">
                  <div className="activity-icon">📝</div>
                  <div className="activity-info">
                    <h3>Quiz #{quiz.quizId?.substring(0, 8) || quiz.id?.substring(0, 8)}</h3>
                    <p>
                      Score: {quiz.score}/{quiz.totalQuestions || 10} (
                      {Math.round((quiz.score / (quiz.totalQuestions || 10)) * 100)}%)
                    </p>
                    <span className="activity-date">
                      {new Date(quiz.completedAt).toLocaleDateString()} at{" "}
                      {new Date(quiz.completedAt).toLocaleTimeString()}
                    </span>
                  </div>
                </div>
              ))}
              <button className="view-all-button" onClick={() => navigate("/dashboard/quiz/history")}>
                View All History
              </button>
            </div>
          ) : (
            <div className="empty-state">
              <p>You haven't completed any quizzes yet.</p>
              <button className="primary-button" onClick={handleCreateQuiz}>
                Take Your First Quiz
              </button>
            </div>
          )}
        </div>

        <div className="quick-actions">
          <h2>Quick Actions</h2>
          <div className="actions-grid">
            <div className="action-card" onClick={handleGenerateQuestions}>
              <div className="action-icon">🤖</div>
              <div className="action-info">
                <h3>Generate Questions</h3>
                <p>Create AI-generated questions on any topic</p>
              </div>
            </div>
            <div className="action-card" onClick={handleCreateQuiz}>
              <div className="action-icon">🎯</div>
              <div className="action-info">
                <h3>Create Quiz</h3>
                <p>Test your knowledge with a custom quiz</p>
              </div>
            </div>
            <div className="action-card" onClick={() => navigate("/leaderboard")}>
              <div className="action-icon">🏆</div>
              <div className="action-info">
                <h3>Leaderboard</h3>
                <p>See how you rank against other learners</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Dashboard
